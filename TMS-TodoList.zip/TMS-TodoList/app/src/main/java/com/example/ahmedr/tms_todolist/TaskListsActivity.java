package com.example.ahmedr.tms_todolist;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class TaskListsActivity extends ListActivity {

    private TextView mySelection;
    //private static final String[] myListItems={"Development List", "Testing List",
    //  "Release List", "New List"};

    private static ArrayList<String> myListItems = new ArrayList<String>(){{
        add("Development List1");
        add("Test List1");
        add("Release List1");
    }};



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_lists);

        Bundle bdl = getIntent().getExtras();
        if(bdl!=null) {
            if(bdl.containsKey("DataAdded")) {
                myListItems = bdl.getStringArrayList("DataAdded");
            }
        }
        setListAdapter(new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, myListItems));
        mySelection=(TextView)findViewById(R.id.mySelection);



    }

    public void onListItemClick(ListView parent, View v, int position,
                                long id) {
        mySelection.setText(myListItems.get(position));
        Intent mIntent = new Intent(TaskListsActivity.this, FragmentTabHostActivity.class);
        mIntent.putExtra("TaskLists", myListItems);
        mIntent.putExtra("TaskListPosition", position);
        startActivity(mIntent);
    }


    public void onButtonClick(View view){
        //myListItems.add("new List");
        //setListAdapter(new ArrayAdapter<String>(this,
        //      android.R.layout.simple_list_item_1, myListItems));
        Intent mIntent = new Intent(TaskListsActivity.this, CreateTaskListActivity.class);
        mIntent.putExtra("Data", myListItems);
        startActivity(mIntent);
    }

}
