package com.example.ahmedr.tms_todolist_donot;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import com.example.ahmedr.tms_todolist_donot.MySimpleArrayAdapter;

import java.util.ArrayList;

public class CustomTaskListActivity extends ListActivity {

    private static ArrayList<String> myListItems = new ArrayList<String>(){{
        add("Development List");
        add("Test List");
        add("Release List");
    }};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_custom_task_list);
        //setListAdapter(new ArrayAdapter<String>(this,
        //      R.layout.activity_custom_task_list, R.id.label, myListItems));
        MySimpleArrayAdapter adapter = new MySimpleArrayAdapter(this, myListItems);
        setListAdapter(adapter);
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        String item = (String) getListAdapter().getItem(position);
        Toast.makeText(this, item + " selected", Toast.LENGTH_LONG).show();
    }
}
