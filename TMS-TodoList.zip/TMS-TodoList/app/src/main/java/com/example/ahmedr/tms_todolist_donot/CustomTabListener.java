package com.example.ahmedr.tms_todolist_donot;

import android.app.Activity;
import android.app.FragmentTransaction;
import android.app.ActionBar;
import android.app.ActionBar.Tab;
public class CustomTabListener implements ActionBar.TabListener{
    @Override
    public void onTabSelected(Tab tab, FragmentTransaction ft) {
// implement your logic here to deal with tab selection
// typically this will be a nested switch on which tab is passed
// and then logic to display/respond to tab menu items



    }
    @Override
    public void onTabUnselected(Tab tab, FragmentTransaction ft) {
// provide any cleanup logic needed when a tab is no longer selected
    }
    @Override
    public void onTabReselected(Tab tab, FragmentTransaction ft) {
// provide logic to deal with state issues on tab reselection
    }
}