package com.example.ahmedr.tms_todolist_donot;

import android.content.Intent;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.TabHost;
import java.util.ArrayList;
import android.view.Menu;
import android.view.MenuItem;

import com.example.ahmedr.tms_todolist.R;

public class TaskTabBarActivity extends AppCompatActivity {//implements ActionBar.TabListener{

    private static ArrayList<String> myTaskListItems1 = new ArrayList<String>(){{
        add("Development Task11");
        add("Development Task21");
        add("Development Task31");
    }};

    private static ArrayList<String> myTaskListItems2 = new ArrayList<String>(){{
        add("Test Task1");
        add("Test Task2");
        add("Test Task3");
    }};

    private static ArrayList<String> myTaskListItems3 = new ArrayList<String>(){{
        add("Release Task1");
        add("Release Task2");
        add("Release Task3");
    }};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_tab_bar);

        TabHost host = (TabHost)findViewById(R.id.tabHost);
        host.setup();

        //Tab 1
        TabHost.TabSpec spec = host.newTabSpec("Tab One");
        spec.setContent(R.id.tab1);
        spec.setIndicator("Tab One");
        host.addTab(spec);

        //Tab 2
        spec = host.newTabSpec("Tab Two");
        spec.setContent(R.id.tab2);
        spec.setIndicator("Tab Two");
        host.addTab(spec);

        //Tab 3
        spec = host.newTabSpec("Tab Three");
        spec.setContent(R.id.tab3);
        spec.setIndicator("Tab Three");
        host.addTab(spec);

       /* ActionBar ab = getSupportActionBar();
        ab.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);


        // Three tab to display in actionbar
        ab.addTab(ab.newTab().setText("Tab 1").setTabListener(this));
        ab.addTab(ab.newTab().setText("Tab 2").setTabListener(this));
        ab.addTab(ab.newTab().setText("Tab 3").setTabListener(this));*/

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }



/*
    @Override
    public void onTabSelected(ActionBar.Tab tab, FragmentTransaction fragmentTransaction) {

        //Called when a tab is selected
        int nTabSelected = tab.getPosition();
        switch (nTabSelected) {
            case 0:
                //Intent mIntent = new Intent(TaskTabBarActivity.this, TaskListActivity.class);
                //mIntent.putExtra("DevelopmentList", myTaskListItems1);
                //startActivity(mIntent);
                setContentView(R.layout.activity_task_list);
                break;
            case 1:
                Intent mIntent1 = new Intent(TaskTabBarActivity.this, TaskListActivity.class);
                mIntent1.putExtra("TestList", myTaskListItems2);
                //startActivity(mIntent1);
                setContentView(R.layout.activity_task_list);
                break;
            case 2:
                Intent mIntent2 = new Intent(TaskTabBarActivity.this, TaskListActivity.class);
                mIntent2.putExtra("ReleaseList", myTaskListItems3);
                //startActivity(mIntent2);
                setContentView(R.layout.activity_task_list);
                break;
        }
    }

    @Override
    public void onTabUnselected(ActionBar.Tab tab, FragmentTransaction fragmentTransaction) {
        // Called when a tab unselected.
    }

    @Override
    public void onTabReselected(ActionBar.Tab tab, FragmentTransaction fragmentTransaction) {

        // Called when a tab is selected again.
    }
    */
}
