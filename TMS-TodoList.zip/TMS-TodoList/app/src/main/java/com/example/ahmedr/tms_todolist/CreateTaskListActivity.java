package com.example.ahmedr.tms_todolist;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

import java.util.ArrayList;

public class CreateTaskListActivity extends AppCompatActivity {

    public EditText myEditText;
    private static ArrayList<String> myListItems = new ArrayList<String>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_task_list);
        Bundle bdl = getIntent().getExtras();
        myListItems = bdl.getStringArrayList("Data");
        // myEditText=(EditText) findViewById(R.id.editListText);
        // myEditText.setText(myListItems.get(1));

    }

    public void onButtonClick(View view){

        myEditText=(EditText) findViewById(R.id.editListText);
        myListItems.add(myEditText.getText().toString());
        Intent mIntent = new Intent(CreateTaskListActivity.this, TaskListsActivity.class);
        mIntent.putExtra("DataAdded", myListItems);
        startActivity(mIntent);

    }

}