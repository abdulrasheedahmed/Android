package com.example.ahmedr.tms_todolist;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTabHost;
import android.view.View;

import java.util.ArrayList;

public class FragmentTabHostActivity extends FragmentActivity  {
    private FragmentTabHost mTabHost;
    private static ArrayList<String> myListItems;
    private static int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment_tab_host);


        Bundle bdl = getIntent().getExtras();
        if(bdl!=null) {
            if(bdl.containsKey("TaskLists")) {
                myListItems = bdl.getStringArrayList("TaskLists");
            }
            if(bdl.containsKey("TaskListPosition")) {
                position = bdl.getInt("TaskListPosition");
            }
        }
        mTabHost = (FragmentTabHost) findViewById(android.R.id.tabhost);
        mTabHost.setup(this, getSupportFragmentManager(), android.R.id.tabcontent);

        for (int i=0; i<myListItems.size(); i++){

            mTabHost.addTab(
                    mTabHost.newTabSpec("tab"+ Integer.toString(i+1)).setIndicator(myListItems.get(i), null),
                    FragmentTab.class, null);
        }

        mTabHost.setCurrentTab(position);

    }

    public void onAddButtonClick(View view){

        Intent mIntent = new Intent(FragmentTabHostActivity.this, CreateTaskActivity.class);
        //mIntent.putExtra("DataAdded", myListItems);
        startActivity(mIntent);

    }
}
