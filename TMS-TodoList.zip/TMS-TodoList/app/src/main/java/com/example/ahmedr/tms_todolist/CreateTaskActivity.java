package com.example.ahmedr.tms_todolist;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.app.Activity;

public class CreateTaskActivity extends Activity implements AdapterView.OnItemSelectedListener{

    private static final String[] myListItems={"In Progress", "Completed",
            "On Hold", "Deferred"};
    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_task);

        //mySelection=(TextView)findViewById(R.id.mySelection);
        Spinner spin=(Spinner)findViewById(R.id.spinner);
        spin.setOnItemSelectedListener(this);
        ArrayAdapter<String> myAdapter=new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item,
                myListItems);
        myAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(myAdapter);
    }
    public void onItemSelected(AdapterView<?> parent,
                               View v, int position, long id) {
        //mySelection.setText(myListItems[position]);
    }
    public void onNothingSelected(AdapterView<?> parent) {
        //mySelection.setText("");
    }


    public void onSaveButtonClick(View view){

       editText=(EditText) findViewById(R.id.taskNameEditText);
       Intent mIntent = new Intent(CreateTaskActivity.this, FragmentTabHostActivity.class);
       mIntent.putExtra("newTaskName", editText.getText().toString());
       startActivity(mIntent);

    }

}
