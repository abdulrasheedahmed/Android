package com.example.ahmedr.tms_todolist;

import android.content.Intent;
import android.support.v4.app.ListFragment;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class FragmentTab extends ListFragment {

    private static ArrayList<String> myTaskListItems1 = new ArrayList<String>(){{
        add("Development Task11");
        add("Development Task21");
        add("Development Task31");
    }};


    private static ArrayList<String> myTaskListItems2 = new ArrayList<String>(){{
        add("Test Task1");
        add("Test Task2");
        add("Test Task3");
    }};

    private static ArrayList<String> myTaskListItems3 = new ArrayList<String>(){{
        add("Release Task1");
        add("Release Task2");
        add("Release Task3");
    }};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_layout, container, false);
        return v;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if(this.getTag().toString().equalsIgnoreCase("tab1")) {
            setListAdapter(new ArrayAdapter<String>(getActivity(),
                    android.R.layout.simple_list_item_multiple_choice, myTaskListItems1));

        }

        if(this.getTag().toString().equalsIgnoreCase("tab2")) {
            setListAdapter(new ArrayAdapter<String>(getActivity(),
                    android.R.layout.simple_list_item_multiple_choice, myTaskListItems2));

        }

        if(this.getTag().toString().equalsIgnoreCase("tab3")) {
            setListAdapter(new ArrayAdapter<String>(getActivity(),
                    android.R.layout.simple_list_item_multiple_choice, myTaskListItems3));

        }
    }


    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        // TODO implement some logic
        Toast.makeText(getActivity(), "Item: " + position, Toast.LENGTH_SHORT).show();
    }


}